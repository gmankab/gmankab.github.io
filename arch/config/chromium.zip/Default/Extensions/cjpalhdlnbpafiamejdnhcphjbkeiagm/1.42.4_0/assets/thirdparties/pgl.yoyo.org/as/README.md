<https://pgl.yoyo.org/as/index.php>:

Site does encourage use of the list for noncommercial uses only, as per 
https://pgl.yoyo.org/ ("everything licensed under the McRae General Public 
License (version 4.r53) ")

Licence can be found at https://pgl.yoyo.org/license/, and is copied below 
for brevity:


    Preamble
    --------
    Your GRAN.


    MCRAE GENERAL PUBLIC LICENSE (version 4.r53)
    --------------------------------------------
    This license applies to any work containing a notice placed by the
    copyright holder (that would be ME) saying it is uses the McRae
    General Public License. "The work" refers to any such work.

    This license stipulates that it is strictly forbidden to redistribute
    or use the work in any manner that could possibly be construed as
    making anybody any money, or I'll sue you. No! You will NOT do that!
    Okee? And if you don't agree with these terms, you can print out the
    source to the work and stick it up your ARSE.

    Aye, but otherwise feel free to take "the work" and do what you like.
    If you're TOO BLOODY LAZY to do it yourself, I cannae help it. OK?
